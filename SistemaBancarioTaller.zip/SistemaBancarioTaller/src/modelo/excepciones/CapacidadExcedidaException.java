package modelo.excepciones;

public class CapacidadExcedidaException extends SistemaBancarioException {
    private int capacidadMaxima;

    
    public CapacidadExcedidaException(String mensaje, int capacidadMaxima) {
        super(mensaje, "CAPACIDAD_EXCEDIDA");         this.capacidadMaxima = capacidadMaxima;
    }

    public int getCapacidadMaxima() { 
        return capacidadMaxima; 
    }

    @Override
    public String toString() {
        return super.toString() + " [capacidadMaxima=" + capacidadMaxima + "]";
    }
}