
package modelo.excepciones;


public class PermisoInsuficienteException extends SistemaBancarioException {
    public PermisoInsuficienteException(String mensaje, String codigoError) {
        super(mensaje, codigoError);
    }
}

