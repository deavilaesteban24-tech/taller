
package modelo.excepciones;


public class EstadoTransaccionInvalidoException extends SistemaBancarioException {
    public EstadoTransaccionInvalidoException(String mensaje, String codigoError) {
        super(mensaje, codigoError);
    }

    
    

   
}

