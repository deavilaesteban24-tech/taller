
package modelo.excepciones;

public class CuentaBloqueadaException extends SistemaBancarioException {
    private String numeroCuenta;

    public CuentaBloqueadaException(String mensaje, String codigoError, String numeroCuenta) {
        super(mensaje, codigoError);
        this.numeroCuenta = numeroCuenta;
    }

    public String getNumeroCuenta() { return numeroCuenta; }

    @Override
    public String toString() {
        return super.toString() + " [numeroCuenta=" + numeroCuenta + "]";
    }
}
