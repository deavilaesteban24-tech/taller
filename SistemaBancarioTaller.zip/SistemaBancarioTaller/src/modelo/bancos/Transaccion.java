package modelo.bancos;

import java.time.LocalDateTime;
import modelo.abstactas.Cuenta;
import modelo.enums.EstadoTransaccion;
import modelo.excepciones.EstadoTransaccionInvalidoException;

public class Transaccion {
    private String id;
    private Cuenta cuentaOrigen;
    private Cuenta cuentaDestino;
    private double monto;
    private EstadoTransaccion estado;
    private LocalDateTime fecha;
    private String descripcion;

    public Transaccion(String id, Cuenta cuentaOrigen, Cuenta cuentaDestino,
                       double monto, String descripcion) {
        this.id = id;
        this.cuentaOrigen = cuentaOrigen;
        this.cuentaDestino = cuentaDestino;
        this.monto = monto;
        this.descripcion = descripcion;
        this.fecha = LocalDateTime.now();
        this.estado = EstadoTransaccion.PENDIENTE;
    }

    public String getId() { return id; }
    public Cuenta getCuentaOrigen() { return cuentaOrigen; }
    public Cuenta getCuentaDestino() { return cuentaDestino; }
    public double getMonto() { return monto; }
    public EstadoTransaccion getEstado() { return estado; }
    public LocalDateTime getFecha() { return fecha; }
    public String getDescripcion() { return descripcion; }

    public void cambiarEstado(EstadoTransaccion nuevo) throws EstadoTransaccionInvalidoException {
        if (this.estado == EstadoTransaccion.COMPLETADA && nuevo == EstadoTransaccion.PENDIENTE) {
            throw new EstadoTransaccionInvalidoException(
                      "Transición inválida de COMPLETADA a PENDIENTE.",
                         "TRANSACCION_INVALIDA");
        }
        this.estado = nuevo;
        
    }
    public String generarComprobante() {
        String origen = (cuentaOrigen != null) ? cuentaOrigen.getnumeroCuenta() : "Banco";
        String destino = (cuentaDestino != null) ? cuentaDestino.getnumeroCuenta() : "—";

        String comprobante = 
                "Comprobante #" + id + "\n" +     
         "Origen: " + origen + "\n" +
        "Destino: " + destino + "\n" +
        "Monto: " + monto + "\n" +
        "Estado: " + estado + "\n" +
         "Fecha: " + fecha + "\n" +
         "Descripción: " + descripcion;

        // si no se encuentra la cuenta destino
        if (cuentaDestino == null) {
            comprobante += "\nNota: Esta transacción corresponde a un " +
                           (descripcion.toLowerCase().contains("deposito") ? "depósito" : "retiro") +
                           " sin cuenta destino.";
        }

        return comprobante;
    }
}