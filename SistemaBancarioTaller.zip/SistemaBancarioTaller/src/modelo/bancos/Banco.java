package modelo.bancos;
import modelo.interfaces.Auditable;
import modelo.abstactas.Cuenta;
import modelo.abstactas.Empleado;
import modelo.personas.ClienteNatural;
import modelo.personas.ClienteEmpresarial;
import modelo.excepciones.CapacidadExcedidaException;
import modelo.excepciones.ClienteNoEncontradoException;

public abstract class Banco implements Auditable {
    private String nombre;
    private Empleado[] empleados;
    private ClienteNatural[] clientesNaturales;
    private ClienteEmpresarial[] clientesEmpresariales;
    private Cuenta[] cuentas;

    private int contadorEmpleados;
    private int contadorNaturales;
    private int contadorEmpresariales;
    private int contadorCuentas;

    public Banco(String nombre) {
        this.nombre = nombre;
        empleados = new Empleado[50];
        clientesNaturales = new ClienteNatural[200];
        clientesEmpresariales = new ClienteEmpresarial[200];
        cuentas = new Cuenta[500];
        contadorEmpleados = 0;
        contadorNaturales = 0;
        contadorEmpresariales = 0;
        contadorCuentas = 0;
    }

    public void registrarCliente(ClienteNatural c) throws CapacidadExcedidaException {
        if (contadorNaturales >= clientesNaturales.length) {
            throw new CapacidadExcedidaException(
                "Capacidad máxima de clientes naturales alcanzada.",
                clientesNaturales.length
            );
        }
        clientesNaturales[contadorNaturales++] = c;
    }

    // Registrar clientes empresariales
    public void registrarCliente(ClienteEmpresarial c) throws CapacidadExcedidaException {
        if (contadorEmpresariales >= clientesEmpresariales.length) {
            throw new CapacidadExcedidaException(
                "Capacidad máxima de clientes empresariales alcanzada.",
                clientesEmpresariales.length
            );
        }
        clientesEmpresariales[contadorEmpresariales++] = c;
    }

    // Registrar empleados
    public void registrarEmpleado(Empleado e) throws CapacidadExcedidaException {
        if (contadorEmpleados >= empleados.length) {
            throw new CapacidadExcedidaException(
                "Capacidad máxima de empleados alcanzada.",
                empleados.length
            );
        }
        empleados[contadorEmpleados++] = e;
    }

    // Abrir cuenta
    public void abrirCuenta(String idCliente, Cuenta c)
            throws ClienteNoEncontradoException, CapacidadExcedidaException {
        if (contadorCuentas >= cuentas.length) {
            throw new CapacidadExcedidaException(
                "Capacidad máxima de cuentas alcanzada.",
                cuentas.length
            );
        }

        ClienteNatural clienteN = buscarClienteNatural(idCliente);
        ClienteEmpresarial clienteE = buscarClienteEmpresarial(idCliente);

        if (clienteN == null && clienteE == null) {
            throw new ClienteNoEncontradoException(
                "Cliente con ID " + idCliente + " no encontrado.",
                "CLIENTE_NO_ENCONTRADO",
                idCliente
            );
        }

        cuentas[contadorCuentas++] = c;
    }

    // Buscar clientes naturales
    public ClienteNatural buscarClienteNatural(String id) throws ClienteNoEncontradoException {
        for (int i = 0; i < contadorNaturales; i++) {
            if (clientesNaturales[i].getId().equals(id)) {
                return clientesNaturales[i];
            }
        }
        throw new ClienteNoEncontradoException(
            "Cliente natural con ID " + id + " no encontrado.",
            "CLIENTE_NO_ENCONTRADO",
            id
        );
    }
    // Buscar clientes empresariales
public ClienteEmpresarial buscarClienteEmpresarial(String id) throws ClienteNoEncontradoException {
    for (int i = 0; i < contadorEmpresariales; i++) {
        if (clientesEmpresariales[i].getId().equals(id)) {
            return clientesEmpresariales[i];
        }
    }
    throw new ClienteNoEncontradoException(
        "Cliente empresarial con ID " + id + " no encontrado.",
        "CLIENTE_NO_ENCONTRADO",
        id
    );
}

    // Calcular nómina total 
    public double calcularNominaTotal() {
        double total = 0;
        for (int i = 0; i < contadorEmpleados; i++) {
            total += empleados[i].calcularSalario();
        }
        return total;
    }

    // Calcular intereses mensuales 
    public void calcularInteresesMensuales() {
        for (int i = 0; i < contadorCuentas; i++) {
            cuentas[i].calcularIntereses();
        }
    }

    
    public String generarAuditoria() {
        return "Banco '" + nombre + "' con " + contadorNaturales + " clientes naturales, "
               + contadorEmpresariales + " clientes empresariales, "
               + contadorCuentas + " cuentas y "
               + contadorEmpleados + " empleados.";
    }
}