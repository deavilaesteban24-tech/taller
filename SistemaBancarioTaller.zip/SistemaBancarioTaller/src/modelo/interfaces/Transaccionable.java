
package modelo.interfaces;

import modelo.excepciones.SaldoInsuficienteException;
import modelo.excepciones.CuentaBloqueadaException;
import modelo.excepciones.DatoInvalidoException;

public interface Transaccionable {
     void depositar(double monto) throws DatoInvalidoException, CuentaBloqueadaException;
    void retirar(double monto) throws DatoInvalidoException, SaldoInsuficienteException, CuentaBloqueadaException;
    double calcularComision(double monto);
    double consultarSaldo();
}

