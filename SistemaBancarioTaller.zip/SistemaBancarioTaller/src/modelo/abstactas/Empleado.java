
package modelo.abstactas;
import java.time.LocalDate;
import java.time.Period;
import modelo.excepciones.DatoInvalidoException;

public abstract class Empleado extends Persona {
    private String legajo;
    private LocalDate fechaContratacion;
    private double salarioBase;
    private boolean activo;
            
            //constructor 
     public Empleado(String id, String nombre, String apellido, LocalDate fechaNacimiento,
                String email, String legajo, LocalDate fechaContratacion,
                double salarioBase, boolean activo) throws DatoInvalidoException {
    super(id, nombre, apellido, fechaNacimiento, email);
    setLegajo(legajo);
    setFechaContratacion(fechaContratacion);
    setSalarioBase(salarioBase);
    setActivo(activo);
}
     
     //metodos abstractos 
     public abstract double calcularSalario();
     public abstract double calcularBono();
     
     
     //se completan los getters
     public String getLegajo() {return legajo;}
    public LocalDate getfechaContratacion() { return fechaContratacion;}
    public double getSalarioBase() {return salarioBase;}
    public boolean isActivo() { return activo;}
    
    //setters con validaciones 
    public void setLegajo(String legajo) throws DatoInvalidoException {
        if (legajo == null || legajo.trim().isEmpty()) {
            throw new DatoInvalidoException("El legajo no puede estar nulo ni vacío.", "Legajo:", legajo);
        }
        this.legajo = legajo;
    }

    public void setFechaContratacion(LocalDate fechaContratacion) throws DatoInvalidoException {
        if (fechaContratacion == null || fechaContratacion.isAfter(LocalDate.now())) {
            throw new DatoInvalidoException("La fecha de contratación no puede ser futura.", "fecha Contratacion", fechaContratacion);
        }
        this.fechaContratacion = fechaContratacion;
    }

    public void setSalarioBase(double salarioBase) throws DatoInvalidoException {
        if (salarioBase <= 0) {
            throw new DatoInvalidoException("El salario base debe ser mayor a 0.", "salario Base", salarioBase);
        }
        this.salarioBase = salarioBase;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }
     
     
     
            //metodo concreto que es heredable
    public int calcularAntiguedad() {
    return Period.between(fechaContratacion, LocalDate.now()).getYears();
    }
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
    
}
