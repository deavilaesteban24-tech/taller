
package modelo.abstactas;
import java.time.LocalDateTime;
import modelo.bancos.Transaccion;
import modelo.excepciones.BancoRuntimeException;
import modelo.excepciones.CuentaBloqueadaException;
import modelo.excepciones.DatoInvalidoException;
import modelo.excepciones.SaldoInsuficienteException;
import modelo.excepciones.SistemaBancarioException;

public abstract class Cuenta {
    
   private String numeroCuenta;
   private double saldo;
   private boolean bloqueada;
   private LocalDateTime fechaCreacion;
   private LocalDateTime ultimaModificacion;
   private String usuarioModificacion;
   
   //Agregamos los arreglos estaticos para el historial 
   private static final int max_transacciones = 20;
   private Transaccion[] historial;
   private int indiceHistorial;
   
   
   public Cuenta(String numeroCuenta, double saldoInicial, String usuarioModificacion){
   
       this.numeroCuenta= numeroCuenta;
       this.saldo = saldoInicial;
       this.bloqueada = false;
       this.fechaCreacion = LocalDateTime.now();
       this.ultimaModificacion = LocalDateTime.now();
       this.usuarioModificacion = usuarioModificacion;
       this.historial = new Transaccion[max_transacciones];
       this.indiceHistorial = 0;
   }
  // Se ponen ahora los metodos abstractos 
   public abstract double calcularInteres();
   public abstract double getlimiteRetiro();
   public abstract String gettipoCuenta();
   
   public String getnumeroCuenta () { return numeroCuenta;}
   public double getsaldo () { return saldo;}
   public boolean isbloqueada () { return bloqueada;}
   public LocalDateTime getfechaCreacion() { return fechaCreacion;}
   public LocalDateTime getultimaModificacion () { return ultimaModificacion;}
   public String getusuarioModificacion () { return usuarioModificacion;   }
   
   public void setbloqueada (boolean bloqueada){this.bloqueada = bloqueada;}
   public void setusuarioModificacion (String usuarioModificacion) { this.usuarioModificacion = usuarioModificacion;  }
   public void setSaldo(double saldo) {
    this.saldo = saldo;
}

   
   //Metodos concretos 
   
   public void verificarBloqueada() throws CuentaBloqueadaException {
        if (bloqueada) {
            throw new CuentaBloqueadaException("La cuenta está bloqueada.", "cuenta bloqueada", numeroCuenta);
        }
    }
   public void agregarAlHistorial(Transaccion t) throws SistemaBancarioException {
   if(indiceHistorial >= max_transacciones) {
   throw new SistemaBancarioException ("Capacidad maxima de historial ya alcanzada" , "ERR-HIST");
    }
   historial[indiceHistorial++] = t;
        ultimaModificacion = LocalDateTime.now();
   }
   public Transaccion[] getHistorial() {
        Transaccion[] copia = new Transaccion[indiceHistorial];
        System.arraycopy(historial, 0, copia, 0, indiceHistorial);
        return copia;}
   
   // Métodos de negocio 
    public void depositar(double monto) throws DatoInvalidoException, CuentaBloqueadaException {
        verificarBloqueada();
        if (monto <= 0) {
            throw new DatoInvalidoException("El monto debe ser positivo.", "monto", monto);
        }
        saldo += monto;
        ultimaModificacion = LocalDateTime.now();
    }

    public void retirar(double monto) throws SaldoInsuficienteException, DatoInvalidoException, CuentaBloqueadaException {
        verificarBloqueada();
        if (monto <= 0) {
            throw new DatoInvalidoException("El monto debe ser positivo.", "monto", monto);
        }
        if (monto > saldo) {
            throw new SaldoInsuficienteException(" El saldo es insuficiente.", "ERR-SALDO", saldo, monto);
        }
        if (monto > getlimiteRetiro()) {
            throw new BancoRuntimeException(" El monto excede el límite de retiro.");
        }
        saldo -= monto;
        ultimaModificacion = LocalDateTime.now();
    }

    public void transferir(Cuenta destino, double monto) throws SaldoInsuficienteException, DatoInvalidoException, CuentaBloqueadaException {
        verificarBloqueada();
        destino.verificarBloqueada();
        if (monto <= 0) {
            throw new DatoInvalidoException("El monto debe ser positivo.", "monto", monto);
        }
        if (monto > saldo) {
            throw new SaldoInsuficienteException("El saldo es insuficiente para transferir.", "ERR-SALDO", saldo, monto);
        }
        this.saldo -= monto;
        destino.saldo += monto;
        ultimaModificacion = LocalDateTime.now();
    }

    public void calcularIntereses() {
    }

       
   
   
   
   
   
   
   
   
   
   
   
   
   
   }
   
   
   
   
   
   
   
   
   
   
   
   
           


   