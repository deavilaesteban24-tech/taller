
package modelo.abstactas;
import java.time.LocalDate;
import modelo.excepciones.DatoInvalidoException;

public abstract class Persona {
    private String id;
    private String nombre;
    private String apellido;
    private LocalDate fechaNacimiento;
    private String email;
    
    public String getId(){return id;}
    public String getNombre(){return nombre;}
    public String getApellido() {return apellido;}
    public LocalDate getFechaNacimiento() {return fechaNacimiento;}
    public String getEmail() { return email;}
    
    //Metodos abstractos
     public abstract int calcularEdad();
    public abstract String obtenerTipo();
    public abstract String obtenerDocumentoIdentidad();
    
     // Método concreto heredable
    public String getNombreCompleto() {
        return nombre + " " + apellido;
    }
   
    
     //constructor 
   public Persona(String id, String nombre, String apellido, LocalDate fechaNacimiento, String email) throws DatoInvalidoException { 
       setId(id);
        setNombre(nombre);
        setApellido(apellido);
        setFechaNacimiento(fechaNacimiento);
         setEmail(email); }
         
       //set con validaciones
        public void setId(String id) throws DatoInvalidoException {
        if (id == null || id.trim().isEmpty()) {
            throw new DatoInvalidoException("El ID no puede ser nulo ni vacío.", "id", id);
        }
        this.id = id;
                       }
    public void setNombre(String nombre) { this.nombre = nombre; }
    
    public void setApellido(String apellido) { this.apellido = apellido; }

    public void setFechaNacimiento(LocalDate fechaNacimiento) throws DatoInvalidoException {
        if (fechaNacimiento == null || fechaNacimiento.isAfter(LocalDate.now())) {
            throw new DatoInvalidoException("La fecha de nacimiento no puede ser futura.", "fechaNacimiento", fechaNacimiento);
        }
        this.fechaNacimiento = fechaNacimiento;
    }
    public void setEmail(String email) throws DatoInvalidoException {
        if (email == null || !email.contains("@")) {
            throw new DatoInvalidoException("El email debe contener '@'.", "email", email);
        }
        this.email = email;
    }
   
   }
