package modelo.empleados;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import modelo.abstactas.Empleado;
import modelo.interfaces.Auditable;
import modelo.interfaces.Consultable;
import modelo.excepciones.DatoInvalidoException;

public  class GerenteSucursal extends Empleado implements Consultable, Auditable {
    private String sucursal;
    private double presupuestoAnual;
    private Empleado[] empleadosACargo;
    private static final int MAX_EMPLEADOS = 30;

    
    private LocalDateTime fechaCreacion;
    private LocalDateTime ultimaModificacion;
    private String usuarioModificacion;

    public GerenteSucursal(String id, String nombre, String apellido, LocalDate fechaNacimiento,
                       String email, String legajo, LocalDate fechaContratacion,
                       double salarioBase, boolean activo,
                       String sucursal, double presupuestoAnual) throws DatoInvalidoException {
    super(id, nombre, apellido, fechaNacimiento, email, legajo, fechaContratacion, salarioBase, activo);
    this.sucursal = sucursal;
    this.presupuestoAnual = presupuestoAnual;
    this.empleadosACargo = new Empleado[MAX_EMPLEADOS];

    this.fechaCreacion = LocalDateTime.now();
    this.ultimaModificacion = LocalDateTime.now();
    this.usuarioModificacion = ""; 
}

    @Override
    public double calcularSalario() {
        double bonoAntiguedad = calcularAntiguedad() * 100; 
        double bonoGerencia = 2000; 
        return getSalarioBase() + bonoAntiguedad + bonoGerencia;
    }

    @Override
    public double calcularBono() {
        
        return presupuestoAnual * 0.01;
    }

    // Consultable
    @Override
    public String obtenerResumen() {
        return "Gerente Sucursal: " + getNombreCompleto() +
               " | Sucursal: " + sucursal +
               " | Empleados a cargo: " + contarEmpleados();
    }

    @Override
    public boolean estaActivo() { return isActivo(); }
    @Override
    public String obtenerTipo() { return "Gerente de Sucursal"; }

    // Auditable
    @Override
    public LocalDateTime obtenerFechaCreacion() { return fechaCreacion; }
    @Override
    public LocalDateTime obtenerUltimaModificacion() { return ultimaModificacion; }
    @Override
    public String obtenerUsuarioModificacion() { return usuarioModificacion; }
    @Override
    public void registrarModificacion(String usuario) {
        this.ultimaModificacion = LocalDateTime.now();
        this.usuarioModificacion = usuario;
    }

    // Getter con copia
    public Empleado[] getEmpleadosACargo() {
        Empleado[] copia = new Empleado[MAX_EMPLEADOS];
        System.arraycopy(empleadosACargo, 0, copia, 0, empleadosACargo.length);
        return copia;
    }

   
    private int contarEmpleados() {
        int count = 0;
        for (Empleado e : empleadosACargo) if (e != null) count++;
        return count;
    }

    @Override
    public int calcularEdad() {
        return Period.between(getFechaNacimiento(), LocalDate.now()).getYears();
    }

    @Override
    public String obtenerDocumentoIdentidad() {
        return "Legajo: " + getLegajo();
    }
}