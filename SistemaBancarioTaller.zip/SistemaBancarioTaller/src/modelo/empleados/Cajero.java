package modelo.empleados;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import modelo.abstactas.Empleado;
import modelo.excepciones.DatoInvalidoException;
import modelo.interfaces.Consultable;
import modelo.interfaces.Auditable;

public   class Cajero extends Empleado implements Consultable, Auditable {
    private String turno; 
    private String sucursalAsignada;
    private int transaccionesDia;
    private LocalDateTime fechaCreacion;
    private LocalDateTime ultimaModificacion;
    private String usuarioModificacion;

   public Cajero(String id, String nombre, String apellido, LocalDate fechaNacimiento,
              String email, String legajo, LocalDate fechaContratacion,
              double salarioBase, boolean activo,
              String turno, String sucursalAsignada, int transaccionesDia) throws DatoInvalidoException {
   
    super(id, nombre, apellido, fechaNacimiento, email, legajo, fechaContratacion, salarioBase, activo);

    this.turno = turno;
    this.sucursalAsignada = sucursalAsignada;
    this.transaccionesDia = transaccionesDia;
}
    @Override
    public double calcularSalario() {
        return getSalarioBase() + (transaccionesDia * 2); // bono por transaccion
    }
     @Override
    public int calcularEdad() {
        return Period.between(getFechaNacimiento(), LocalDate.now()).getYears();
    }

    @Override
    public String obtenerDocumentoIdentidad() {
        return "Legajo: " + getLegajo();
    }

    @Override
    public String obtenerTipo() {
        return "Cajero";
    }
    @Override
    public double calcularBono() {
        return transaccionesDia * 2;
    }

    @Override
    public String obtenerResumen() {
        return "Cajero en sucursal " + sucursalAsignada + " | Turno: " + turno;
    }
   
    public String generarAuditoria() {
        return "Cajero " + getNombreCompleto() + " con " + transaccionesDia + " transacciones hoy.";
    }

    @Override
public boolean estaActivo() { 
    return isActivo(); 
}
@Override
public LocalDateTime obtenerFechaCreacion() { return fechaCreacion; }

@Override
public LocalDateTime obtenerUltimaModificacion() { return ultimaModificacion; }

@Override
public String obtenerUsuarioModificacion() { return usuarioModificacion; }

@Override
public void registrarModificacion(String usuario) {
    this.ultimaModificacion = LocalDateTime.now();
    this.usuarioModificacion = usuario;
}
}
    