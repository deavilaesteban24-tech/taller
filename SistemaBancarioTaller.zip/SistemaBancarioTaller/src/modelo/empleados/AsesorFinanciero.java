package modelo.empleados;

import java.time.LocalDate;
import java.time.LocalDateTime;
import modelo.abstactas.Empleado;
import modelo.excepciones.DatoInvalidoException;
import modelo.interfaces.Auditable;
import modelo.interfaces.Consultable;

public class AsesorFinanciero extends Empleado implements Consultable, Auditable {
    private double comisionBase;
    private double metasMensuales;
    private Object[] clientesAsignados; 
    private static final int MAX_CLIENTES = 20;

    // Auditable
    private LocalDateTime fechaCreacion;
    private LocalDateTime ultimaModificacion;
    private String usuarioModificacion;

    public AsesorFinanciero(String id, String nombre, String apellido, LocalDate fechaNacimiento,
                            String email, String legajo, LocalDate fechaContratacion,
                            double salarioBase, boolean activo,
                            double comisionBase, double metasMensuales) throws DatoInvalidoException {
        super(id, nombre, apellido, fechaNacimiento, email, legajo, fechaContratacion, salarioBase, activo);
        this.comisionBase = comisionBase;
        this.metasMensuales = metasMensuales;
        this.clientesAsignados = new Object[MAX_CLIENTES];

        this.fechaCreacion = LocalDateTime.now();
        this.ultimaModificacion = LocalDateTime.now();
        this.usuarioModificacion = ""; 
    }

    @Override
    public double calcularSalario() {
        
        return getSalarioBase() + comisionBase;
    }

    @Override
    public double calcularBono() {
        
        return metasMensuales * 0.05;
    }

    // Consultable
    @Override
    public String obtenerResumen() {
        return "Asesor Financiero: " + getNombreCompleto() +
               " | Comisión base: " + comisionBase +
               " | Metas mensuales: " + metasMensuales;
    }

    @Override
    public boolean estaActivo() { return isActivo(); }
    @Override
    public String obtenerTipo() { return "Asesor Financiero"; }
    @Override
public int calcularEdad() {return java.time.Period.between(getFechaNacimiento(), LocalDate.now()).getYears();}
    @Override
   public String obtenerDocumentoIdentidad() {
    return "Legajo: " + getLegajo();}
    // Auditable
    @Override
    public LocalDateTime obtenerFechaCreacion() { return fechaCreacion; }
    @Override
    public LocalDateTime obtenerUltimaModificacion() { return ultimaModificacion; }
    @Override
    public String obtenerUsuarioModificacion() { return usuarioModificacion; }
    @Override
    public void registrarModificacion(String usuario) {
        this.ultimaModificacion = LocalDateTime.now();
        this.usuarioModificacion = usuario;
    }
}