package modelo.cuentas;

import modelo.abstactas.Cuenta;
import modelo.excepciones.CuentaBloqueadaException;
import modelo.excepciones.DatoInvalidoException;
import modelo.excepciones.SaldoInsuficienteException;
import modelo.interfaces.Consultable;
import modelo.interfaces.Transaccionable;
import modelo.interfaces.Auditable;

import java.time.LocalDateTime;

public class CuentaCredito extends Cuenta implements Consultable, Transaccionable, Auditable {
    private double limiteCredito;
    private double tasaInteres;
    private double deudaActual;

    public CuentaCredito(String numeroCuenta, double saldoInicial, String usuarioModificacion,
                         double limiteCredito, double tasaInteres) {
        super(numeroCuenta, saldoInicial, usuarioModificacion);
        this.limiteCredito = limiteCredito;
        this.tasaInteres = tasaInteres;
        this.deudaActual = 0;
    }

    @Override
    public void retirar(double monto) throws DatoInvalidoException, SaldoInsuficienteException, CuentaBloqueadaException {
        verificarBloqueada();
        if (monto <= 0) throw new DatoInvalidoException("Monto inválido.", "retiro", monto);
        if (deudaActual + monto > limiteCredito) {
            throw new SaldoInsuficienteException("Se excede el límite de crédito.", "ERR-CREDITO", getsaldo(), monto);
        }
        deudaActual += monto;
    }

    public void aplicarInteresMensual() { deudaActual += deudaActual * tasaInteres / 12; }

    @Override
    public double calcularInteres() { return deudaActual * tasaInteres; }
    @Override
    public double getlimiteRetiro() { return limiteCredito - deudaActual; }
    @Override
    public String gettipoCuenta() { return "Cuenta de Crédito"; }

    // Consultable
    @Override
    public String obtenerResumen() { return "Cuenta Crédito: " + getnumeroCuenta() + " | Deuda: " + deudaActual; }
    @Override
    public boolean estaActivo() { return !isbloqueada(); }
    @Override
    public String obtenerTipo() { return "Cuenta de Crédito"; }

    // Transaccionable
    @Override
    public void depositar(double monto) throws DatoInvalidoException, CuentaBloqueadaException {
        verificarBloqueada();
        if (monto <= 0) throw new DatoInvalidoException("Monto inválido.", "deposito", monto);
        deudaActual -= monto;
        if (deudaActual < 0) {
            setSaldo(getsaldo() + Math.abs(deudaActual));
            deudaActual = 0;
        }
    }
    @Override
    public double calcularComision(double monto) { return 0; }
    @Override
    public double consultarSaldo() { return getsaldo(); }

    // Auditable
    @Override
    public LocalDateTime obtenerFechaCreacion() { return getfechaCreacion(); }
    @Override
    public LocalDateTime obtenerUltimaModificacion() { return getultimaModificacion(); }
    @Override
    public String obtenerUsuarioModificacion() { return getusuarioModificacion(); }
    @Override
    public void registrarModificacion(String usuario) { setusuarioModificacion(usuario); }
}
     
        
    
    
    
    
    
    
    

