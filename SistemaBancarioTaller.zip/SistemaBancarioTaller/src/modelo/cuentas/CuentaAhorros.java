package modelo.cuentas;

import modelo.abstactas.Cuenta;
import modelo.excepciones.CuentaBloqueadaException;
import modelo.excepciones.DatoInvalidoException;
import modelo.excepciones.SaldoInsuficienteException;
import modelo.interfaces.Consultable;
import modelo.interfaces.Transaccionable;
import modelo.interfaces.Auditable;

import java.time.LocalDateTime;

public class CuentaAhorros extends Cuenta implements Consultable, Transaccionable, Auditable {
    private double tasaInteres;
    private int retirosMesActual;
    private int maxRetirosMes;

    public CuentaAhorros(String numeroCuenta, double saldoInicial, String usuarioModificacion,
                         double tasaInteres, int maxRetirosMes) {
        super(numeroCuenta, saldoInicial, usuarioModificacion);
        this.tasaInteres = tasaInteres;
        this.maxRetirosMes = maxRetirosMes;
        this.retirosMesActual = 0;
    }

    @Override
    public void retirar(double monto) throws DatoInvalidoException, SaldoInsuficienteException, CuentaBloqueadaException {
        verificarBloqueada();
        if (retirosMesActual >= maxRetirosMes) {
            throw new DatoInvalidoException("Se alcanzó el máximo de retiros permitidos este mes.", "retiros", monto);
        }
        super.retirar(monto);
        retirosMesActual++;
    }

    public void aplicarInteresMensual() {
        setSaldo(getsaldo() + (getsaldo() * tasaInteres / 12));
    }

    @Override
    public double calcularInteres() { return getsaldo() * tasaInteres; }
    @Override
    public double getlimiteRetiro() { return getsaldo(); }
    @Override
    public String gettipoCuenta() { return "Cuenta de Ahorros"; }

    // Métodos de Consultable
    @Override
    public String obtenerResumen() { return "Cuenta Ahorros: " + getnumeroCuenta() + " | Saldo: " + getsaldo(); }
    @Override
    public boolean estaActivo() { return !isbloqueada(); }
    @Override
    public String obtenerTipo() { return "Cuenta de Ahorros"; }

    // Métodos de Transaccionable
    @Override
    public void depositar(double monto) throws DatoInvalidoException, CuentaBloqueadaException { super.depositar(monto); }
    @Override
    public double calcularComision(double monto) { return 0; }
    @Override
    public double consultarSaldo() { return getsaldo(); }

    // Métodos de Auditable
    @Override
    public LocalDateTime obtenerFechaCreacion() { return getfechaCreacion(); }
    @Override
    public LocalDateTime obtenerUltimaModificacion() { return getultimaModificacion(); }
    @Override
    public String obtenerUsuarioModificacion() { return getusuarioModificacion(); }
    @Override
    public void registrarModificacion(String usuario) { setusuarioModificacion(usuario); }
}