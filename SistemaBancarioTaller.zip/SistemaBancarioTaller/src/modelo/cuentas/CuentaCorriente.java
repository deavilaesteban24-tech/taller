package modelo.cuentas;

import modelo.abstactas.Cuenta;
import modelo.excepciones.CuentaBloqueadaException;
import modelo.excepciones.DatoInvalidoException;
import modelo.excepciones.SaldoInsuficienteException;
import modelo.interfaces.Consultable;
import modelo.interfaces.Transaccionable;
import modelo.interfaces.Auditable;

import java.time.LocalDateTime;

public class CuentaCorriente extends Cuenta implements Consultable, Transaccionable, Auditable {
    private double montoSobregiro;
    private double comisionMantenimiento;

    public CuentaCorriente(String numeroCuenta, double saldoInicial, String usuarioModificacion,
                           double montoSobregiro, double comisionMantenimiento) {
        super(numeroCuenta, saldoInicial, usuarioModificacion);
        this.montoSobregiro = montoSobregiro;
        this.comisionMantenimiento = comisionMantenimiento;
    }

    @Override
    public void retirar(double monto) throws DatoInvalidoException, SaldoInsuficienteException, CuentaBloqueadaException {
        verificarBloqueada();
        if (monto <= 0) throw new DatoInvalidoException("Monto inválido.", "retiro", monto);
        if (getsaldo() + montoSobregiro < monto) {
            throw new SaldoInsuficienteException("Saldo insuficiente incluso con sobregiro.", "ERR-SOBREGIRO", getsaldo(), monto);
        }
        setSaldo(getsaldo() - monto);
    }

    public void aplicarComisionMensual() { setSaldo(getsaldo() - comisionMantenimiento); }

    @Override
    public double calcularInteres() { return 0; }
    @Override
    public double getlimiteRetiro() { return getsaldo() + montoSobregiro; }
    @Override
    public String gettipoCuenta() { return "Cuenta Corriente"; }

    // Consultable
    @Override
    public String obtenerResumen() { return "Cuenta Corriente: " + getnumeroCuenta() + " | Saldo: " + getsaldo(); }
    @Override
    public boolean estaActivo() { return !isbloqueada(); }
    @Override
    public String obtenerTipo() { return "Cuenta Corriente"; }

    // Transaccionable
    @Override
    public void depositar(double monto) throws DatoInvalidoException, CuentaBloqueadaException { super.depositar(monto); }
    @Override
    public double calcularComision(double monto) { return comisionMantenimiento; }
    @Override
    public double consultarSaldo() { return getsaldo(); }

    // Auditable
    @Override
    public LocalDateTime obtenerFechaCreacion() { return getfechaCreacion(); }
    @Override
    public LocalDateTime obtenerUltimaModificacion() { return getultimaModificacion(); }
    @Override
    public String obtenerUsuarioModificacion() { return getusuarioModificacion(); }
    @Override
    public void registrarModificacion(String usuario) { setusuarioModificacion(usuario); }
}