package modelo.personas;

import java.time.LocalDate;
import java.time.Period;
import java.time.LocalDateTime;
import modelo.abstactas.Cuenta;
import modelo.abstactas.Persona;
import modelo.excepciones.DatoInvalidoException;
import modelo.interfaces.Consultable;
import modelo.interfaces.Notificable;
import modelo.interfaces.Auditable;

public class ClienteNatural extends Persona implements Consultable, Notificable, Auditable {

    private String cedula;
    private String direccion;
    private String telefono;
    private Cuenta[] cuentas;
    private static final int max_cuentas = 5;

    // Auditoría
    private LocalDateTime fechaCreacion;
    private LocalDateTime ultimaModificacion;
    private String usuarioModificacion;

    private boolean aceptaNotificaciones;

    public ClienteNatural(String id, String nombre, String apellido, LocalDate fechaNacimiento, String email,
                          String cedula,String telefono, boolean aceptaNotificaciones)
            throws DatoInvalidoException {
        super(id, nombre, apellido, fechaNacimiento, email);
        this.cedula = cedula;
        
        this.telefono = telefono;
        this.cuentas = new Cuenta[max_cuentas];
        this.aceptaNotificaciones = aceptaNotificaciones;

        // Inicialización de auditable
        this.fechaCreacion = LocalDateTime.now();
        this.ultimaModificacion = LocalDateTime.now();
        this.usuarioModificacion = "Sistema";
    }

    // Getters y setters
    public String getCedula() { return cedula; }
    public void setCedula(String cedula) { this.cedula = cedula; }

  
    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }

    public Cuenta[] getCuentas() {
    Cuenta[] copia = new Cuenta[max_cuentas];
    System.arraycopy(cuentas, 0, copia, 0, cuentas.length);
    return copia;
}

    // Métodos heredados de Persona
    @Override
    public int calcularEdad() {
        return Period.between(getFechaNacimiento(), LocalDate.now()).getYears();
    }

    @Override
    public String obtenerTipo() {
        return "Cliente Natural";
    }

    @Override
    public String obtenerDocumentoIdentidad() {
        return "Cédula: " + cedula;
    }

    @Override
    public String toString() {
        return "ClienteNatural{" +
                "Nombre='" + getNombreCompleto() + '\'' +
                ", Cedula='" + cedula + '\'' +
                ", Direccion='" + direccion + '\'' +
                ", Telefono='" + telefono + '\'' +
                '}';
    }

    // Métodos de Consultable
    @Override
    public String obtenerResumen() {
        return "Cliente Natural: " + getNombreCompleto() + " | Cédula: " + cedula;
    }

    @Override
    public boolean estaActivo() {
        return true; 
    }

    // Métodos de Notificable
    @Override
    public void notificar(String mensaje) {
        if (aceptaNotificaciones) {
            System.out.println("Notificación para " + getNombreCompleto() + ": " + mensaje);
        }
    }

    @Override
    public String obtenerContacto() {
        return telefono; 
    }

    @Override
    public boolean aceptaNotificaciones() {
        return aceptaNotificaciones;
    }

    // Métodos de Auditable
    @Override
    public LocalDateTime obtenerFechaCreacion() {
        return fechaCreacion;
    }

    @Override
    public LocalDateTime obtenerUltimaModificacion() {
        return ultimaModificacion;
    }

    @Override
    public String obtenerUsuarioModificacion() {
        return usuarioModificacion;
    }

    @Override
    public void registrarModificacion(String usuario) {
        this.ultimaModificacion = LocalDateTime.now();
        this.usuarioModificacion = usuario;
    }
}
      