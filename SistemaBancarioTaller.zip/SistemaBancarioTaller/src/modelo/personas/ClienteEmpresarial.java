package modelo.personas;

import java.time.LocalDate;
import java.time.Period;
import java.time.LocalDateTime;
import modelo.abstactas.Persona;
import modelo.abstactas.Cuenta;
import modelo.excepciones.DatoInvalidoException;
import modelo.interfaces.Consultable;
import modelo.interfaces.Notificable;
import modelo.interfaces.Auditable;

public class ClienteEmpresarial extends Persona implements Consultable, Notificable, Auditable {

    private String nit;
    private String razonSocial;
    private String representanteLegal;
    private Cuenta[] cuentas;
    private static final int max_cuentas = 5;

    // Auditoría
    private LocalDateTime fechaCreacion;
    private LocalDateTime ultimaModificacion;
    private String usuarioModificacion;

    private boolean aceptaNotificaciones;
    private String contacto; 

    public ClienteEmpresarial(String id, String nombre, String apellido, LocalDate fechaNacimiento, String email,
                              String nit, String razonSocial, String representanteLegal,
                              String contacto, boolean aceptaNotificaciones) throws DatoInvalidoException {
        super(id, nombre, apellido, fechaNacimiento, email);
        this.nit = nit;
        this.razonSocial = razonSocial;
        this.representanteLegal = representanteLegal;
        this.cuentas = new Cuenta[max_cuentas];
        this.contacto = contacto;
        this.aceptaNotificaciones = aceptaNotificaciones;

        //  auditable
        this.fechaCreacion = LocalDateTime.now();
        this.ultimaModificacion = LocalDateTime.now();
        this.usuarioModificacion = "Sistema";
    }

    // Getters y setters
    public String getNit() { return nit; }
    public void setNit(String nit) { this.nit = nit; }

    public String getRazonSocial() { return razonSocial; }
    public void setRazonSocial(String razonSocial) { this.razonSocial = razonSocial; }

    public String getRepresentanteLegal() { return representanteLegal; }
    public void setRepresentanteLegal(String representanteLegal) { this.representanteLegal = representanteLegal; }

    public Cuenta[] getCuentas() {
    Cuenta[] copia = new Cuenta[max_cuentas];
    System.arraycopy(cuentas, 0, copia, 0, cuentas.length);
    return copia;
}
    // Métodos abstractos de Persona
    @Override
    public int calcularEdad() {
        return Period.between(getFechaNacimiento(), LocalDate.now()).getYears();
    }

    @Override
    public String obtenerTipo() {
        return "Cliente Empresarial";
    }

    @Override
    public String obtenerDocumentoIdentidad() {
        return "NIT: " + nit;
    }

    @Override
    public String toString() {
        return "ClienteEmpresarial{" +
                "RazonSocial='" + razonSocial + '\'' +
                ", NIT='" + nit + '\'' +
                ", RepresentanteLegal='" + representanteLegal + '\'' +
                '}';
    }

    // Métodos de Consultable
    @Override
    public String obtenerResumen() {
        return "Cliente Empresarial: " + razonSocial + " | NIT: " + nit;
    }

    @Override
    public boolean estaActivo() {
        return true; 
    }

    // Métodos de Notificable
    @Override
    public void notificar(String mensaje) {
        if (aceptaNotificaciones) {
            System.out.println("Notificación para " + razonSocial + ": " + mensaje);
        }
    }

    @Override
    public String obtenerContacto() {
        return contacto;
    }

    @Override
    public boolean aceptaNotificaciones() {
        return aceptaNotificaciones;
    }

    // Métodos de Auditable
    @Override
    public LocalDateTime obtenerFechaCreacion() {
        return fechaCreacion;
    }

    @Override
    public LocalDateTime obtenerUltimaModificacion() {
        return ultimaModificacion;
    }

    @Override
    public String obtenerUsuarioModificacion() {
        return usuarioModificacion;
    }

    @Override
    public void registrarModificacion(String usuario) {
        this.ultimaModificacion = LocalDateTime.now();
        this.usuarioModificacion = usuario;
    }
}