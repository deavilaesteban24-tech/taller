package principal;
import java.time.LocalDate;
import modelo.empleados.AsesorFinanciero;
import modelo.empleados.Cajero;
import modelo.empleados.GerenteSucursal;
import modelo.excepciones.DatoInvalidoException;
import modelo.personas.ClienteNatural;
import modelo.personas.ClienteEmpresarial;
import modelo.cuentas.CuentaCorriente;
import modelo.cuentas.CuentaAhorros;
import modelo.cuentas.CuentaCredito;
import modelo.abstactas.Cuenta;
import modelo.excepciones.CuentaBloqueadaException;
import modelo.excepciones.SaldoInsuficienteException;
import modelo.abstactas.Empleado;


public class SistemaBancarioDemo {
    public static void main(String[] args) {
        
        try {
            //  Registrar cliente
            ClienteNatural cn1 = new ClienteNatural(
    "100", "Carito", "Cohen", LocalDate.of(2007, 7, 11),
    "juan@gmail.com", "CC101", "3001234567", true);

            ClienteNatural cn2 = new ClienteNatural(
    "101", "Esteban", "Garcia", LocalDate.of(2000, 5, 20),
    "maria@mail.com", "CC102", "3009876543", false
);

      ClienteEmpresarial ce = new ClienteEmpresarial(
    "102", "popsy", "S.A.", LocalDate.of(2005, 1, 1),
    "popsy@gmail.com", "NIT201", "AndreaRS.A.",
    "Carlos Pérez", "6051234567", true
);

            //  Abrir cuentas
            CuentaCorriente cc = new CuentaCorriente("CC001", 3000, "juan gomez", 500, 20);

            CuentaAhorros ca = new CuentaAhorros( "CA001", 2000, "carolinac", 0.05, 3);

            CuentaCredito cr = new CuentaCredito("CR001", 0, "AndreaR", 5000, 0.02);

            // mensaje de error CuentaBloqueadaException
            try { cc.depositar(500);
                  cc.setbloqueada(true);
                  cc.depositar(500);} 
            catch (CuentaBloqueadaException | DatoInvalidoException e) {
                 System.out.println("Error: " + e.getMessage());}

        // captura el error SaldoInsuficienteException
                  try {ca.retirar(500);
                      ca.retirar(5000);}
                  catch (SaldoInsuficienteException | DatoInvalidoException | CuentaBloqueadaException e) {
                    System.out.println("Error: " + e.getMessage());}

                  
       // realizar trasnferencia 
                         try {
               cc.transferir(ca, 200);
              } catch (SaldoInsuficienteException | DatoInvalidoException | CuentaBloqueadaException e) {
                  System.out.println("Error: " + e.getMessage());}

            //  Arreglo de empleados
            Empleado[] empleados = {
                new GerenteSucursal("001","Melany","pérez",LocalDate.of(1980,5,10),"mel@gmail.com","G001",LocalDate.of(2010,3,15),5000,true,
                "Sucursal Centro",200000),
                new AsesorFinanciero("002","jose ","Martinez",LocalDate.of(1990,8,20),"luis@banco.com","A002",LocalDate.of(2015,7,1),3000,true,500,10000),
                new Cajero("003","irma","figueroa",LocalDate.of(1995,2,5),"luna@gmail.com","C003",LocalDate.of(2020,1,10),2000,true,"Mañana","Sucursal Norte",120)
            };
            for (Empleado e : empleados) {
                System.out.println(e.getNombreCompleto() + " salario: " + e.calcularSalario());
            }

            // arreglo de cuentas
            Cuenta[] cuentas = {cc, ca, cr};
            for (Cuenta c : cuentas) {
                System.out.println("Cuenta " + c.getnumeroCuenta() + " interés: " + c.calcularInteres());
            }

            
     
            // notificacion al cliente 
            cn1.notificar("Su cuenta fue actualizada.");
            ce.notificar("Su crédito fue aprobado.");

            

            //  Nómina total
            double nominaTotal = 0;
            for (Empleado e : empleados) {
                nominaTotal += e.calcularSalario();
            }
            System.out.println("Nómina total: " + nominaTotal);

            
        } catch (DatoInvalidoException e) {
            System.err.println("Error al crear entidad: " + e.getMessage());
        }
    }
    
    
    
    
    
    
    
      
    
    
    
    
    
    
    
    
}
